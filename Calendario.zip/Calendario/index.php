<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <meta charset='utf-8' />
  <!--Jquery-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <!-- Bootstrap-->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
    integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
    crossorigin="anonymous"></script>

  <!------------------------------------------------------------------------------------------>
  <!-- Fullcalendar-->
  <!--Estilos fullcalendar-->
  <link href='core\main.css' rel='stylesheet' />
  <link href='daygrid\main.css' rel='stylesheet' />
  <link href='list\main.css' rel='stylesheet' />
  <link href='timegrid\main.css' rel='stylesheet' />
  <!--Script fullcalendar-->
  <script src='core\main.js'></script>
  <script src='daygrid\main.js'></script>
  <script src='list\main.js'></script>
  <script src='timegrid\main.js'></script>
  <script src='interaction\main.js'></script>


  <script>

    document.addEventListener('DOMContentLoaded', function () {
      var calendarEl = document.getElementById('calendar');

      var calendar = new FullCalendar.Calendar(calendarEl, {

        plugins: ['dayGrid', 'timeGrid', 'list','interaction'],
        defaultView: 'timeGridWeek',
        header: {
          left: 'prev,next,today,Miboton',
          center: 'title',
          right: 'dayGridMonth,timeGridWeek,timeGridDay'
        },
        customButtons: {
          Miboton: {
            text: "Boton",
            click: function () {

              $('#exampleModal').modal('toggle');
            }
          }
        },
        dateClick:function(info){
          $('#exampleModal').modal('show');
          console.log(info);
          calendar.addEvent({title:"Evento x",date:info.dateStr});

        },
        eventClick:function(info){
        console.log(info);
        console.log(info.event.title);
        console.log(info.event.start);
        console.log(info.event.end);
        console.log(info.event.backgroundColor);
        console.log(info.event.textColor);
        console.log(info.event.extendedProps.descripcion)
        },
        events:[
         {
          title:"Casita!",
          start:"2024-03-28 13:00",
          descripcion:"descripcion de casita"
         },{
          title:"Lenguaje!",
          start:"2024-03-29 8:00",
          end:"2024-03-29 9:30",
          color:"red",
          textColor:"peru",
          descripcion:"descripcion de lenguaje"
         },{
         title:"mates!",
          start:"2024-03-29 9:45",
          end:"2024-03-29 11:15"
         }
        ]

      });
      calendar.setOption('locale', 'Es');
      calendar.render();
    })
  </script>
  <!------------------------------------------------------------------------------------------>
  <style>
    html,
    body {
      margin: 0;
      padding: 0;
      font-family: Arial, Helvetica, sans-serif;
      font-size: 14px;
    }

    #calendar {
      max-width: 900px;
      margin: 40px auto;
    }
  </style>
</head>

<body>
  <!-- Modal -->
  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          ...
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary">Save changes</button>
        </div>
      </div>
    </div>
  </div>

  <div class="alert alert-danger">aaaaa</div>
  <div id='calendar'> </div>
 
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
    crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"
    integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy"
    crossorigin="anonymous"></script>
</body>

</html>